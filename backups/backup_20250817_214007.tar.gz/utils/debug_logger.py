"""
🎯 Task#9-4 AP-1 Ph4 Step4（再挑戦）- 監視レイヤー（OL-0＋Level1）
データ流れ監視レイヤー: Python側デバッグロガー
作成日: 2025-08-15
"""

import uuid
import json
import time
import re
from datetime import datetime
from functools import wraps
from flask import g, request
import logging
from logging.handlers import RotatingFileHandler
import os

class DataFlowLogger:
    """データフロー監視用ロガークラス"""
    
    def __init__(self, app=None):
        self.app = app
        self.logger = None
        self.enabled = False
        self.level = 1
        self.sampling_rate = 1.0
        
        # 機密情報マスキングパターン
        self.sensitive_patterns = [
            (r'sk-[a-zA-Z0-9]{32,}', '****_API_KEY'),  # OpenAI API key
            (r'AIza[a-zA-Z0-9_-]{35}', '****_GEMINI_KEY'),  # Gemini API key  
            (r'sk-ant-[a-zA-Z0-9_-]{32,}', '****_CLAUDE_KEY'),  # Claude API key
            (r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}', '****_EMAIL'),  # Email
            (r'\b\d{3}-\d{4}-\d{4}\b', '****_PHONE'),  # Phone
            (r'"password"\s*:\s*"[^"]*"', '"password": "****"'),  # Password in JSON
            (r'Bearer\s+[a-zA-Z0-9._-]+', 'Bearer ****'),  # Bearer token
        ]
    
    def init_app(self, app):
        """Flaskアプリケーション初期化"""
        self.app = app
        
        # 環境変数から設定読み込み
        self.enabled = os.getenv('DEBUG_MONITOR_ENABLED', 'false').lower() == 'true'
        self.level = int(os.getenv('DEBUG_MONITOR_LEVEL', '1'))
        self.sampling_rate = float(os.getenv('DEBUG_SAMPLING', '1.0'))
        
        if not self.enabled:
            return
        
        # RotatingFileHandlerでログ設定
        if not os.path.exists('logs'):
            os.makedirs('logs')
            
        handler = RotatingFileHandler(
            'logs/debug.log',
            maxBytes=10*1024*1024,  # 10MB
            backupCount=5
        )
        
        formatter = logging.Formatter(
            '%(asctime)s - %(levelname)s - %(message)s'
        )
        handler.setFormatter(formatter)
        
        self.logger = logging.getLogger('data_flow')
        self.logger.setLevel(logging.DEBUG)
        self.logger.addHandler(handler)
        
        # Request-ID ミドルウェア設定
        @app.before_request
        def before_request():
            g.request_id = self.generate_request_id()
            g.start_time = time.time()
            g.data_flow_logger = self
            
        @app.after_request  
        def after_request(response):
            if hasattr(g, 'request_id'):
                response.headers['X-Request-ID'] = g.request_id
            return response
    
    def generate_request_id(self):
        """Request ID生成"""
        return str(uuid.uuid4())[:8]
    
    def mask_sensitive_data(self, text):
        """機密情報のマスキング"""
        if not isinstance(text, str):
            text = str(text)
            
        for pattern, replacement in self.sensitive_patterns:
            text = re.sub(pattern, replacement, text, flags=re.IGNORECASE)
            
        return text
    
    def log_data_flow(self, location, operation, data=None, **kwargs):
        """データフロー記録"""
        if not self.enabled or not self.logger:
            return
            
        # サンプリング制御
        if self.sampling_rate < 1.0:
            import random
            if random.random() > self.sampling_rate:
                return
        
        # P3: リクエストコンテキスト非依存化
        from flask import has_request_context
        
        # 基本情報
        log_entry = {
            'req_id': getattr(g, 'request_id', 'no-context') if has_request_context() else 'no-context',
            'time': datetime.now().strftime('%H:%M:%S.%f')[:-3],
            'location': location,
            'operation': operation
        }
        
        # データ情報
        if data is not None:
            data_str = str(data)
            log_entry.update({
                'data_preview': self.mask_sensitive_data(data_str[:100]),
                'data_size': len(data_str)
            })
        
        # 追加情報
        if hasattr(g, 'start_time'):
            elapsed = (time.time() - g.start_time) * 1000
            log_entry['elapsed_ms'] = round(elapsed, 2)
            
        log_entry.update(kwargs)
        
        # ログ出力
        log_message = json.dumps(log_entry, ensure_ascii=False)
        self.logger.info(log_message)
        
        # コンソール出力（開発時）
        if self.app and self.app.debug:
            print(f"🔍 [{log_entry['req_id']}] {location}:{operation} -> {log_entry.get('data_preview', 'N/A')}")

def watch_io(location_name, operation_suffix=''):
    """入出力監視デコレーター"""
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            if not hasattr(g, 'data_flow_logger'):
                return func(*args, **kwargs)
                
            logger = g.data_flow_logger
            
            # 入力ログ
            input_data = {
                'args_count': len(args),
                'kwargs_keys': list(kwargs.keys())
            }
            logger.log_data_flow(
                location_name,
                f"{func.__name__}_START{operation_suffix}",
                input_data
            )
            
            start_time = time.time()
            try:
                # 実行
                result = func(*args, **kwargs)
                
                # 成功ログ
                elapsed = (time.time() - start_time) * 1000
                logger.log_data_flow(
                    location_name,
                    f"{func.__name__}_OUTPUT{operation_suffix}",
                    result,
                    elapsed_ms=round(elapsed, 2)
                )
                
                return result
                
            except Exception as e:
                # エラーログ
                elapsed = (time.time() - start_time) * 1000
                logger.log_data_flow(
                    location_name,
                    f"{func.__name__}_ERROR{operation_suffix}",
                    str(e),
                    elapsed_ms=round(elapsed, 2)
                )
                raise
                
        return wrapper
    return decorator

# グローバルインスタンス
data_flow_logger = DataFlowLogger()